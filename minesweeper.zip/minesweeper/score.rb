class Score
  attr_accessor :name, :time
  def initialize(name, time)
    @name = name
    @time = time
  end
end